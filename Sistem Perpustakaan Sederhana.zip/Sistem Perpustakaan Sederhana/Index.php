<!DOCTYPE html>
<html>
<head>
    <title>Menu Utama Perpustakaan</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <h1 class="judul">Selamat Datang di Perpustakaan</h1>
    <ul class="menu">
        <li><a href="peminjaman.php">Peminjaman Buku</a></li>
        <li><a href="pengembalian.php">Pengembalian Buku</a></li>
        <li><a href="daftar_buku.php">Daftar Buku</a></li>
    </ul>
</body>
</html>
