<?php
// Mulai sesi untuk mengakses variabel $_SESSION
session_start();

// Cek apakah tombol Submit diklik
if (isset($_POST['submit'])) {
    // Tangkap data dari formulir
    $nama = $_POST['nama'];
    $tanggal_pengembalian = $_POST['tanggal_pengembalian'];
    $judul = $_POST['judul'];

    // Simpan data pengembalian ke dalam array
    $pengembalian = array(
        'nama' => $nama,
        'tanggal_pengembalian' => $tanggal_pengembalian,
        'judul' => $judul
    );

    // Tambahkan data pengembalian ke dalam $_SESSION['data_pengembalian']
    if (!isset($_SESSION['data_pengembalian'])) {
        $_SESSION['data_pengembalian'] = array();
    }
    array_push($_SESSION['data_pengembalian'], $pengembalian);

    // Redirect kembali ke halaman pengembalian.php setelah berhasil mengupload
    header("Location: pengembalian.php");
    exit();
} else {
    // Jika tombol Submit tidak diklik, redirect ke halaman pengembalian.php
    header("Location: pengembalian.php");
    exit();
}
?>
