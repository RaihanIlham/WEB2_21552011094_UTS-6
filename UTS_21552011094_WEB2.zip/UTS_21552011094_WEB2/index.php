<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu Utama</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1, h2, h3 {
            text-align: center;
        }

        .menu-buttons {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
        }

        .menu-buttons button {
            padding: 10px 20px;
            font-size: 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .menu-buttons button:hover {
            background-color: #4CAF50; /* Warna saat tombol dihover */
            color: white;
        }

        a {
            text-decoration: none;
            color: inherit;
        }

        .menu-links {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
        }

        .menu-links button {
            padding: 10px 20px;
            font-size: 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
            background-color: #3498db; /* Warna default tombol */
            color: white;
        }

        .menu-links button:hover {
            background-color: #2980b9; /* Warna saat tombol dihover */
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Selamat Datang di Perpustakaan</h1>
        <div>
            <div class="menu-links">
                <a href="daftar_buku.php"><button>Daftar Buku</button></a>
                <a href="peminjaman.php"><button>Peminjaman</button></a>
                <a href="pengembalian.php"><button>Pengembalian</button></a>
            </div>
        </div>
    </div>
</body>
</html>
