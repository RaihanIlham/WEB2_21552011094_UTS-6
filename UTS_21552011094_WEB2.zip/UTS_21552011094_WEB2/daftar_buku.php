<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Buku</title>
    <style>
        body {
    font-family: Arial, sans-serif;
    background-color: #f8f9fa;
    margin: 0;
    padding: 20px;
}

.container {
    max-width: 800px;
    margin: 0 auto;
    background-color: #fff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

h2 {
    margin-top: 0;
    color: #333;
}

form {
    margin-bottom: 20px;
}

input[type="text"], input[type="submit"] {
    padding: 8px;
    margin-right: 10px;
    border: 1px solid #ccc;
    border-radius: 4px;
}

input[type="submit"] {
    background-color: #007bff;
    color: #fff;
    border: none;
    cursor: pointer;
}

table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}

th, td {
    padding: 10px;
    text-align: left;
    border-bottom: 1px solid #ddd;
}

th {
    background-color: #007bff;
    color: #fff;
}

tr:hover {
    background-color: #f2f2f2;
}

a {
    color: #007bff;
    text-decoration: none;
}

a:hover {
    text-decoration: underline;
}
    </style>
</head>
<body>
    <h2>Daftar Buku</h2>
    <form action="" method="get">
        <label for="search">Cari Buku:</label>
        <input type="text" id="search" name="search" placeholder="Masukkan kata kunci">
        <input type="submit" value="Cari">
    </form>
    <form action="" method="post">
        <label for="judul">Judul:</label>
        <input type="text" id="judul" name="judul" required>
        <label for="pengarang">Pengarang:</label>
        <input type="text" id="pengarang" name="pengarang" required>
        <label for="tahun">Tahun Terbit:</label>
        <input type="text" id="tahun" name="tahun" required>
        <label for="isbn">ISBN:</label>
        <input type="text" id="isbn" name="isbn" required>
        <input type="submit" name="submit" value="Tambah Buku">
    </form>
    

    <?php
    // Memeriksa apakah variabel $daftar_buku sudah ada di session
    session_start();
    if (!isset($_SESSION['daftar_buku'])) {
        // Jika belum ada, inisialisasikan sebagai array kosong
        $_SESSION['daftar_buku'] = array();
    }

    // Menambahkan buku baru jika ada data yang dikirimkan melalui form
    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["submit"])) {
        $judul = $_POST["judul"];
        $pengarang = $_POST["pengarang"];
        $tahun = $_POST["tahun"];
        $isbn = $_POST["isbn"];

        // Menambahkan buku baru ke dalam array
        $buku_baru = array(
            "judul" => $judul,
            "pengarang" => $pengarang,
            "tahun" => $tahun,
            "isbn" => $isbn
        );
        array_push($_SESSION['daftar_buku'], $buku_baru);

        // Menampilkan pesan sukses dengan alert JavaScript
        echo "<script>alert('Buku baru berhasil ditambahkan!');</script>";
    }

    if (isset($_GET['hapus'])) {
        $index = $_GET['hapus'];
        if (isset($_SESSION['daftar_buku'][$index])) {
            unset($_SESSION['daftar_buku'][$index]);
            // Menampilkan notifikasi alert JavaScript setelah data dihapus
            echo "<script>alert('Buku berhasil dihapus!');</script>";
        }
    }

    // Fungsi untuk mencari buku berdasarkan kata kunci
function cariBuku($daftar_buku, $kata_kunci) {
    $hasil_pencarian = array();
    foreach ($daftar_buku as $buku) {
        if (stripos($buku['judul'], $kata_kunci) !== false ||
            stripos($buku['pengarang'], $kata_kunci) !== false ||
            stripos($buku['tahun'], $kata_kunci) !== false ||
            stripos($buku['isbn'], $kata_kunci) !== false) {
            array_push($hasil_pencarian, $buku);
        }
    }
    return $hasil_pencarian;
}

// Memeriksa apakah ada kata kunci pencarian yang dikirimkan
$hasil_pencarian = array();
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET["search"])) {
    $kata_kunci = $_GET["search"];
    $hasil_pencarian = cariBuku($_SESSION['daftar_buku'], $kata_kunci);
}
    ?>

<h3>Hasil Pencarian</h3>
        <div class="daftar-buku">
            <table>
                <tr>
                    <th>Judul</th>
                    <th>Pengarang</th>
                    <th>Tahun Terbit</th>
                    <th>ISBN</th>
                    <th>Aksi</th>
                </tr>
                <?php foreach ($hasil_pencarian as $index => $buku) : ?>
                    <tr>
                        <td><?php echo $buku['judul']; ?></td>
                        <td><?php echo $buku['pengarang']; ?></td>
                        <td><?php echo $buku['tahun']; ?></td>
                        <td><?php echo $buku['isbn']; ?></td>
                        <td><a href="?hapus=<?php echo $index; ?>" onclick="return confirm('Apakah Anda yakin ingin menghapus buku ini?')">Hapus</a></td>
                    </tr>
                <?php endforeach; ?>
            </table>
        </div>

<?php if (!empty($_SESSION['daftar_buku'])) : ?>
   
    <h3>Daftar Buku</h3>
    <div class="daftar-buku">
        <table>
            <tr>
                <th>Judul</th>
                <th>Pengarang</th>
                <th>Tahun Terbit</th>
                <th>ISBN</th>
                <th>Aksi</th>
            </tr>
            <?php foreach ($_SESSION['daftar_buku'] as $buku) : ?>
                <tr>
                    <td><?php echo $buku['judul']; ?></td>
                    <td><?php echo $buku['pengarang']; ?></td>
                    <td><?php echo $buku['tahun']; ?></td>
                    <td><?php echo $buku['isbn']; ?></td>
                    <td><a href="?hapus=<?php echo $index; ?>" onclick="return confirm('Apakah Anda yakin ingin menghapus buku ini?')">Hapus</a></td>
                </tr>
            <?php endforeach; ?>
        </table>
    </div>
<?php endif; ?>
</body>
</html>
