<?php
session_start();

// Cek jika data buku dipilih
if (isset($_POST['buku']) && !empty($_POST['buku'])) {
    $buku_dipinjam = $_POST['buku'];

    // Hapus buku yang dipilih dari daftar buku
    if (isset($_SESSION['daftar_buku'])) {
        foreach ($_SESSION['daftar_buku'] as $key => $buku) {
            if ($buku['judul'] === $buku_dipinjam) {
                unset($_SESSION['daftar_buku'][$key]);
                break; // Hentikan iterasi setelah buku ditemukan dan dihapus
            }
        }
    }
}

// Simulasikan proses peminjaman buku dengan menunggu beberapa detik
// Di sini Anda dapat menambahkan logika penyimpanan data peminjaman ke database atau sumber daya lainnya
// Misalnya, dengan fungsi sleep() untuk simulasi
sleep(2);

// Setelah proses selesai, tampilkan notifikasi dan arahkan kembali ke menu peminjaman.php
echo "<script>alert('Peminjaman buku berhasil!');</script>";
header("Location: peminjaman.php");
exit();
?>
